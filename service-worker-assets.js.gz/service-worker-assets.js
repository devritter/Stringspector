self.assetsManifest = {
  "version": "hc5b27xk",
  "assets": [
    {
      "hash": "sha256-YNLhPUP/EcSs5EsPjYldsSQz0T0LbeLG/3P/2g5WdFM=",
      "url": "_framework/BlazingDev.BlazingExtensions.4jn2yimwyg.wasm"
    },
    {
      "hash": "sha256-QaU3MCJZXUPpTg3z+sdNujuTSOqUW4O70/Rc6aQj1xU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7yvofxhswa.wasm"
    },
    {
      "hash": "sha256-D/ZUWrvE7bqOtBfOWuLj+4RNqOvNZ0SnjD6QrBwUcb8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.pq7fdyw1tb.wasm"
    },
    {
      "hash": "sha256-nHUowzi3IaVHVh8WuBjUSX2fSXqxpGgpbYlWdRWGU4c=",
      "url": "_framework/Microsoft.AspNetCore.Components.w3xocfp4a6.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-Ba5NdPQTvHVjnFX7kh/XyQIVNwfdoGXkKHF8w2H6PU0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.p7b5uiooiy.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-X3FD79kxAt45fQjpJH6KyQjenCmJKCx9f1thG9M50BQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.bp5ehnjzgo.wasm"
    },
    {
      "hash": "sha256-tXQZqZqNvPMoYp2INR4AOHcvE8kWly2WAYbjvmmuiXU=",
      "url": "_framework/Microsoft.Extensions.Options.9zsgy7ya5a.wasm"
    },
    {
      "hash": "sha256-TYdWPCwhKBdHQ79Fa7lunjzdUXfcxyaR1fAk0y11/ig=",
      "url": "_framework/Microsoft.Extensions.Primitives.tcgeh3akx1.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-EZJacz/1GrjdgVfN0PwzWnVwmRFOED77BLJhh7x/uiI=",
      "url": "_framework/Stringspector.vsivtwgtt6.wasm"
    },
    {
      "hash": "sha256-oAJSLyyKZLb2L14FuqUzwyE9LPIdI/RaivBr51TV5Lw=",
      "url": "_framework/System.Collections.Concurrent.kfvdh3g277.wasm"
    },
    {
      "hash": "sha256-gBNEkTslmx0UB/hHYh39tC+H1oTs2xoQ+HZho1rzccM=",
      "url": "_framework/System.Collections.Immutable.chlbikffaa.wasm"
    },
    {
      "hash": "sha256-oXdhfmdzbZmJ6boyhTBgBnrXndoUrL5sY6suZaXjQnA=",
      "url": "_framework/System.Collections.r5dbpecgcj.wasm"
    },
    {
      "hash": "sha256-ggftgc5cU4VTXzEcEGBVl+OtnGRGmlZ9ZZHkKMVLxYw=",
      "url": "_framework/System.ComponentModel.28u698euyz.wasm"
    },
    {
      "hash": "sha256-zl1io6ghGdo10AbSAP7yG2QIhik3wTcUHjkdMj4KKTs=",
      "url": "_framework/System.ComponentModel.Primitives.yjkrlyc8w1.wasm"
    },
    {
      "hash": "sha256-HfzWFVy/IP6a169xtLFvSDmcX0xbNo9Gayccv/s3FXE=",
      "url": "_framework/System.Console.v1q4vye659.wasm"
    },
    {
      "hash": "sha256-JA6sPl6GA5NH8pNdn7k4E0ophulug+EchR9kvweDkS0=",
      "url": "_framework/System.IO.Pipelines.g5ih8ovpg3.wasm"
    },
    {
      "hash": "sha256-iiF7FfWnKAir7SZ1Rg8H6GMTtHxRX8Dypr8z//W8zvI=",
      "url": "_framework/System.Linq.u606wa1sob.wasm"
    },
    {
      "hash": "sha256-lIzG8K3dpwqMKzyOa06q1+TiCFFm4eNcmG0GRUGv/dk=",
      "url": "_framework/System.Memory.s4gblmctz6.wasm"
    },
    {
      "hash": "sha256-PuONLjVT+RdY6SF7OiLiUWRgrDDy0Yhg/3WsHIKKNh0=",
      "url": "_framework/System.Net.Http.if1wca2g7s.wasm"
    },
    {
      "hash": "sha256-S21BwAjdSlZYujl9gymU48gTnFdfUyHO8N4chrKPCN0=",
      "url": "_framework/System.Net.Primitives.rcgya37loz.wasm"
    },
    {
      "hash": "sha256-OVGrjXY5uH9jgBW1l/ULalUMFJL6Ll5ykan6MI21xKM=",
      "url": "_framework/System.Private.CoreLib.xy9ru242xq.wasm"
    },
    {
      "hash": "sha256-Y2AKAJaxW5OpWRULlYoaH/BL+nNs3Cgh4xcUmCgMYnk=",
      "url": "_framework/System.Private.Uri.dkcc1hhxoo.wasm"
    },
    {
      "hash": "sha256-VS4CSyZJNRAj+SrJqgbXBFWlGMlNDgM4rbwJ6gTH5qg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.x50649m5t2.wasm"
    },
    {
      "hash": "sha256-I5OU8Lqx6tAIoFrNrvLMWs8KD30jMgh/0yLTcEe19Nc=",
      "url": "_framework/System.Runtime.r2g3b543ck.wasm"
    },
    {
      "hash": "sha256-3w9jcvf72CdfcHber8bV+MG+QG9Eov1eSxYBJ65smAE=",
      "url": "_framework/System.Text.Encodings.Web.3fsw0egfwc.wasm"
    },
    {
      "hash": "sha256-iZyDezaji13OVrTmcOVv+54XqlLzVihFDKRK38M196I=",
      "url": "_framework/System.Text.Json.br65e92o6u.wasm"
    },
    {
      "hash": "sha256-a1x4KEOaZWJ4r71Zc65+cbIT7+6ly6vMXTy5Vwgu3fI=",
      "url": "_framework/System.Text.RegularExpressions.bsbnt5dus0.wasm"
    },
    {
      "hash": "sha256-qLlPFmKy2H/65YalyMDiJXJpyZ/3p0s/XTj2VkET5YM=",
      "url": "_framework/System.Web.HttpUtility.41fhstb43o.wasm"
    },
    {
      "hash": "sha256-EQTVlR2YWqQeu76fQu0Knt5uNHK3F38In2rVc/YDlIA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-9oJpFjF0TqJ0olZBjwJ5Xj3IkMyGjohtjbAhiNdFTBs=",
      "url": "_framework/dotnet.native.ann9bewb11.js"
    },
    {
      "hash": "sha256-QpjoxtuVBT+tlI4FUaO3UclSWEXsC27vtb1Vj6Rw9i8=",
      "url": "_framework/dotnet.native.mm5htdy6w9.wasm"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-moYtxyNB1k4rjHE/RZP7YTFmndQJ0gUJdjjbfua1wdg=",
      "url": "_framework/netstandard.ya1kjsqnni.wasm"
    },
    {
      "hash": "sha256-21owDoU7tlIG+Jtt60mAwBKvIORmlN5SGkhM2B1e0Bc=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-ivBkhZi5EWBA/fAdI4Qiy90NymVPE2vMbyoiwtl7AGA=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-I8yTF9hLE7xb5+t9BDUE+AE1MeuiTGbQRNzjE90GYIk=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-opCKoYwpPWb+9MHifDQI0rEtFSaFWzFpB7N4zMt7yJA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-BgIIkCrCntX2j9e9ccZLZ4hUV2swqkRj5yCD/km2tb4=",
      "url": "manifest.webmanifest"
    }
  ]
};
